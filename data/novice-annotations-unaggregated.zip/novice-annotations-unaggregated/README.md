Each of the annotators was assigned ~10 arguments and their respective annotator id can be found in the filename as `group-X-member-Y`.

Each file contains the annotations in the following format:
```json
{
  "<argument_id>-<argument_dimension>: "<annotation>",
    ...
  }
```

Where `<argument_id>` is the id of the argument and `<argument_dimension>` is the dimension of the argument. The annotation is a string that can be one of the following: `3` (High), `2` (Medium), `1` (Low), `?` (Cannot judge).

----

**Quality dimensions:** The argument quality dimensions can be found in the `data/dimensions_definitions.jsonl` file, as well as in the [annotation guidelines](https://github.com/nelliemirz/llms-as-argument-quality-annotators/blob/main/data/annotation-guidelines/novice-annotation-guidelines.pdf).

**Arguments:** see `data/arguments.jsonl`.

**Aggregated annotations:** see `data/human_annotations/novice.tsv`.